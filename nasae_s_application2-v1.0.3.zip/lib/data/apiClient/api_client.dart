import 'package:nasae_s_application2/core/app_export.dart';

class ApiClient extends GetConnect {}
