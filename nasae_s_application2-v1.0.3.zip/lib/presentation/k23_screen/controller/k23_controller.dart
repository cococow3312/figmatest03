import 'package:nasae_s_application2/core/app_export.dart';import 'package:nasae_s_application2/presentation/k23_screen/models/k23_model.dart';class K23Controller extends GetxController {Rx<K23Model> k23ModelObj = K23Model().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
