class K23Model { }
