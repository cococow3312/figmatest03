class K48Model { }
