import 'package:get/get.dart';import 'k4_item_model.dart';class K30Model {RxList<K4ItemModel> k4ItemList = RxList.filled(3,K4ItemModel());

 }
