class K22Model { }
