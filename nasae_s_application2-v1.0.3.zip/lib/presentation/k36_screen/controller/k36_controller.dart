import 'package:nasae_s_application2/core/app_export.dart';import 'package:nasae_s_application2/presentation/k36_screen/models/k36_model.dart';class K36Controller extends GetxController {Rx<K36Model> k36ModelObj = K36Model().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
