import 'package:get/get.dart';import 'k6_item_model.dart';class K36Model {RxList<K6ItemModel> k6ItemList = RxList.filled(2,K6ItemModel());

 }
