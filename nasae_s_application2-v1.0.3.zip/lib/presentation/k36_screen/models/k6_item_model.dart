class K6ItemModel { }
