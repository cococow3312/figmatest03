import 'package:get/get.dart';import 'three_item_model.dart';class ThreeModel {RxList<ThreeItemModel> threeItemList = RxList.filled(3,ThreeItemModel());

 }
