class ThreeItemModel { }
