import 'package:get/get.dart';import 'listrectangle752_item_model.dart';class K16Model {RxList<Listrectangle752ItemModel> listrectangle752ItemList = RxList.filled(2,Listrectangle752ItemModel());

 }
