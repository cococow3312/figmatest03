class Listrectangle752ItemModel { }
