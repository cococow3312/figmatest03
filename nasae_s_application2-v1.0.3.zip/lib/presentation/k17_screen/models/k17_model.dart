import 'package:get/get.dart';import 'k1_item_model.dart';class K17Model {RxList<K1ItemModel> k1ItemList = RxList.filled(2,K1ItemModel());

 }
