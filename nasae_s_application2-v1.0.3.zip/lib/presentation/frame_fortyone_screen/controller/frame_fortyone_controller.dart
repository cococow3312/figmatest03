import 'package:nasae_s_application2/core/app_export.dart';
import 'package:nasae_s_application2/presentation/frame_fortyone_screen/models/frame_fortyone_model.dart';

class FrameFortyoneController extends GetxController {
  Rx<FrameFortyoneModel> frameFortyoneModelObj = FrameFortyoneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
