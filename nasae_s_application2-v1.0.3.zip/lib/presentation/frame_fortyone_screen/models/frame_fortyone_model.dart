class FrameFortyoneModel { }
