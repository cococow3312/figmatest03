import 'package:get/get.dart';import 'one2_item_model.dart';class One3Model {RxList<One2ItemModel> one2ItemList = RxList.filled(3,One2ItemModel());

 }
