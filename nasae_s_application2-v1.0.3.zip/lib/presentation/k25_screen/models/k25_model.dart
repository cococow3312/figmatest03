class K25Model { }
