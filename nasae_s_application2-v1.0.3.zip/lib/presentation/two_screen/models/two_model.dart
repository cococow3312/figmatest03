import 'package:get/get.dart';import 'two_item_model.dart';class TwoModel {RxList<TwoItemModel> twoItemList = RxList.filled(3,TwoItemModel());

 }
