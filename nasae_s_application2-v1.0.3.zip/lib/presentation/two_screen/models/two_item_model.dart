class TwoItemModel { }
