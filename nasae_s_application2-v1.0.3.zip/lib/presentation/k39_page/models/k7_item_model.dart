class K7ItemModel { }
