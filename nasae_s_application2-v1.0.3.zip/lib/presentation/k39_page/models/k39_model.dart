import 'package:get/get.dart';import 'k7_item_model.dart';class K39Model {RxList<K7ItemModel> k7ItemList = RxList.filled(2,K7ItemModel());

 }
