import 'package:nasae_s_application2/core/app_export.dart';import 'package:nasae_s_application2/presentation/k39_page/models/k39_model.dart';class K39Controller extends GetxController {K39Controller(this.k39ModelObj);

Rx<K39Model> k39ModelObj;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
