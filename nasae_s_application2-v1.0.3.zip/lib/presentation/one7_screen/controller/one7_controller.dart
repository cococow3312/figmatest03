import 'package:nasae_s_application2/core/app_export.dart';import 'package:nasae_s_application2/presentation/one7_screen/models/one7_model.dart';class One7Controller extends GetxController {Rx<One7Model> one7ModelObj = One7Model().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
