class One7Model { }
