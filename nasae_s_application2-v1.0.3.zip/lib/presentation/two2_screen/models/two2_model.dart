import 'package:get/get.dart';import 'two2_item_model.dart';class Two2Model {RxList<Two2ItemModel> two2ItemList = RxList.filled(3,Two2ItemModel());

 }
