class OneItemModel { }
