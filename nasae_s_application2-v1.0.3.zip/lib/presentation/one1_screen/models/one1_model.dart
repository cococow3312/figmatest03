import 'package:get/get.dart';import 'one_item_model.dart';class One1Model {RxList<OneItemModel> oneItemList = RxList.filled(3,OneItemModel());

 }
