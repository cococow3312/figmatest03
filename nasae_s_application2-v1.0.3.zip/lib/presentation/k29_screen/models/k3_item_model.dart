class K3ItemModel { }
