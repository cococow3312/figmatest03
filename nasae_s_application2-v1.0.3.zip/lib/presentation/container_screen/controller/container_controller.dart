import 'package:nasae_s_application2/core/app_export.dart';import 'package:nasae_s_application2/presentation/container_screen/models/container_model.dart';import 'package:nasae_s_application2/widgets/custom_bottom_bar.dart';class ContainerController extends GetxController {Rx<ContainerModel> containerModelObj = ContainerModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
@override void onInit() {  } 
 }
