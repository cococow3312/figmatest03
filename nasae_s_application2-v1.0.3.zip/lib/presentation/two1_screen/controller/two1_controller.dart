import 'package:nasae_s_application2/core/app_export.dart';import 'package:nasae_s_application2/presentation/two1_screen/models/two1_model.dart';class Two1Controller extends GetxController {Rx<Two1Model> two1ModelObj = Two1Model().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
