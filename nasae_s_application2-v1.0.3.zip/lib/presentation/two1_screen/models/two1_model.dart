import 'package:get/get.dart';import 'two1_item_model.dart';class Two1Model {RxList<Two1ItemModel> two1ItemList = RxList.filled(6,Two1ItemModel());

 }
