import 'package:get/get.dart';import 'one5_item_model.dart';class One8Model {RxList<One5ItemModel> one5ItemList = RxList.filled(2,One5ItemModel());

 }
