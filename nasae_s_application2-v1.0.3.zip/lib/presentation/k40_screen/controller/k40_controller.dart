import 'package:nasae_s_application2/core/app_export.dart';import 'package:nasae_s_application2/presentation/k40_screen/models/k40_model.dart';import 'package:nasae_s_application2/widgets/custom_bottom_bar.dart';class K40Controller extends GetxController {Rx<K40Model> k40ModelObj = K40Model().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
