import 'package:get/get.dart';import 'k8_item_model.dart';class K40Model {RxList<K8ItemModel> k8ItemList = RxList.filled(2,K8ItemModel());

 }
