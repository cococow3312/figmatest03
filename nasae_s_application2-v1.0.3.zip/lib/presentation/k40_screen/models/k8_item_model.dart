class K8ItemModel { }
