class K0ItemModel { }
