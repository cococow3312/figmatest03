import 'package:get/get.dart';import 'k0_item_model.dart';class K10Model {RxList<K0ItemModel> k0ItemList = RxList.filled(3,K0ItemModel());

 }
