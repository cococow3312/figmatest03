import 'package:nasae_s_application2/core/app_export.dart';import 'package:nasae_s_application2/presentation/k31_screen/models/k31_model.dart';class K31Controller extends GetxController {Rx<K31Model> k31ModelObj = K31Model().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
