class K38Model { }
