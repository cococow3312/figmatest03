import 'package:get/get.dart';import 'one1_item_model.dart';class One2Model {RxList<One1ItemModel> one1ItemList = RxList.filled(6,One1ItemModel());

 }
