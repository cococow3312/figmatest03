import 'package:nasae_s_application2/core/app_export.dart';import 'package:nasae_s_application2/presentation/one2_screen/models/one2_model.dart';class One2Controller extends GetxController {Rx<One2Model> one2ModelObj = One2Model().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
