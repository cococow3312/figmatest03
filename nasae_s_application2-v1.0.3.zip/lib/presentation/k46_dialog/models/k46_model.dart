class K46Model { }
