class K6Model { }
