class AppNavigationModel { }
