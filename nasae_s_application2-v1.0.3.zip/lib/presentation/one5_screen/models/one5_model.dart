import 'package:get/get.dart';import 'one3_item_model.dart';class One5Model {RxList<One3ItemModel> one3ItemList = RxList.filled(2,One3ItemModel());

 }
