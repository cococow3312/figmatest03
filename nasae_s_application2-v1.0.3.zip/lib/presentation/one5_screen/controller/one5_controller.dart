import 'package:nasae_s_application2/core/app_export.dart';import 'package:nasae_s_application2/presentation/one5_screen/models/one5_model.dart';class One5Controller extends GetxController {Rx<One5Model> one5ModelObj = One5Model().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
