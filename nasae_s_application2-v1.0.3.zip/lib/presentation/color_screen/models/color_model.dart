class ColorModel { }
