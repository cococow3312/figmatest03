import 'package:get/get.dart';import 'four_item_model.dart';class FourModel {RxList<FourItemModel> fourItemList = RxList.filled(3,FourItemModel());

 }
