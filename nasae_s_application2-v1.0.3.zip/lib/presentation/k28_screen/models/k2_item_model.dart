class K2ItemModel { }
