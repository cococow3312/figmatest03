class OneModel { }
