/// Checks if string is phone number
bool isValidPhone(String? inputString, {bool isRequired = false}) { 
bool isInputStringValid = false;

if ((inputString == null ? true : inputString.isEmpty) && !isRequired) {

isInputStringValid = true;

}

if (inputString != null) {

if (inputString.length > 16 || inputString.length < 6) return false;

const pattern = r'^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$';

final regExp = RegExp(pattern);

isInputStringValid = regExp.hasMatch(inputString) ;

}

return isInputStringValid; } 