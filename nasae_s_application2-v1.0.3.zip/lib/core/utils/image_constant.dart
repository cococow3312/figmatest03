class ImageConstant {
  static String imgTelevision = 'assets/images/img_television.svg';

  static String imgVector47 = 'assets/images/img_vector47.svg';

  static String imgArrowrightWhiteA700 =
      'assets/images/img_arrowright_white_a700.svg';

  static String imgCall40x40 = 'assets/images/img_call_40x40.svg';

  static String imgImage8 = 'assets/images/img_image8.png';

  static String imgRectangle278252x720 =
      'assets/images/img_rectangle278_252x720.png';

  static String imgArrowleftGray600 =
      'assets/images/img_arrowleft_gray_600.svg';

  static String imgRectangle752200x150 =
      'assets/images/img_rectangle752_200x150.png';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgCampaignfill0 = 'assets/images/img_campaignfill0.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgContrast = 'assets/images/img_contrast.svg';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgArrowup = 'assets/images/img_arrowup.svg';

  static String imgLocation16x16 = 'assets/images/img_location_16x16.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgFile16x16 = 'assets/images/img_file_16x16.svg';

  static String imgKey = 'assets/images/img_key.svg';

  static String imgPrinter = 'assets/images/img_printer.svg';

  static String imgSearch32x32 = 'assets/images/img_search_32x32.svg';

  static String imgFingerprint = 'assets/images/img_fingerprint.svg';

  static String imgClose14x14 = 'assets/images/img_close_14x14.svg';

  static String imgGroup12 = 'assets/images/img_group12.svg';

  static String imgHome40x40 = 'assets/images/img_home_40x40.svg';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgUser24x24 = 'assets/images/img_user_24x24.svg';

  static String imgImage14 = 'assets/images/img_image14.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgGlobe = 'assets/images/img_globe.svg';

  static String imgUser16x16 = 'assets/images/img_user_16x16.svg';

  static String imgGlobe40x40 = 'assets/images/img_globe_40x40.svg';

  static String imgRectangle752 = 'assets/images/img_rectangle752.png';

  static String imgFingerprint75x66 = 'assets/images/img_fingerprint_75x66.svg';

  static String imgArrowleft24x24 = 'assets/images/img_arrowleft_24x24.svg';

  static String imgGroup = 'assets/images/img_group.svg';

  static String imgFolder = 'assets/images/img_folder.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgRectangle39570 = 'assets/images/img_rectangle39570.png';

  static String imgNotification = 'assets/images/img_notification.svg';

  static String imgImage7 = 'assets/images/img_image7.png';

  static String imgMobile = 'assets/images/img_mobile.svg';

  static String imgUser1 = 'assets/images/img_user_1.svg';

  static String imgFrame1647 = 'assets/images/img_frame1647.png';

  static String imgPolygon1 = 'assets/images/img_polygon1.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgMail = 'assets/images/img_mail.svg';

  static String imgMail24x24 = 'assets/images/img_mail_24x24.svg';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgMenu24x24 = 'assets/images/img_menu_24x24.svg';

  static String imgFolder20x20 = 'assets/images/img_folder_20x20.svg';

  static String imgCall = 'assets/images/img_call.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgRectangle278 = 'assets/images/img_rectangle278.png';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgUser40x40 = 'assets/images/img_user_40x40.svg';

  static String imgTrash = 'assets/images/img_trash.svg';

  static String imgCalendar = 'assets/images/img_calendar.svg';

  static String imgBarstatusbar = 'assets/images/img_barstatusbar.svg';

  static String imgMinimize = 'assets/images/img_minimize.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgMicrophone = 'assets/images/img_microphone.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
